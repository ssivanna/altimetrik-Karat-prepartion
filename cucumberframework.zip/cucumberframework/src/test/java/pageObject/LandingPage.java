package pageObject;

public class LandingPage {
	static int b = 3;

	public static void main(String args[]) {
		
		
		/*
		 * int a; System.out.println(b);
		 * 
		 * long l=1234567;
		 * 
		 * System.out.println(l);
		 */
		 
		/*
		 * int a=10; //int res=++a; System.out.println(++a);
		 */
		
		int a=10; b=20;
		
		/*
		 * int c; c=a; a=b; b=c; System.out.println(a + " " + b);
		 */
		 a=a+b;
		 b=a-b;
		 a=b+b;
		 
		 System.out.println( a + " " + b);
		 
		 

	}  

}
