package pageObject;

public class offersPage {

}
