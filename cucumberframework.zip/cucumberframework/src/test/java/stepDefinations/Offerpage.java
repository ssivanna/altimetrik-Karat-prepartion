package stepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.Then;
import util.TestContextSetup;

public class Offerpage {
	//public WebDriver driver;
	  //public String landingpageProduct;
	 public String offerPageProduct;
	  	  
	  TestContextSetup testContextSetup;
 public Offerpage(TestContextSetup testContextSetup) {
	    	
	    	 
	    	this.testContextSetup=testContextSetup;
	    	
	    	
	    	
	    	
			// TODO Auto-generated constructor stub
		}
	
	
	@Then("user search for same shortname in offers page to check if product exist")
	public void user_search_for_same_shortname_in_offers_page_to_check_if_product_exist() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		testContextSetup.driver.findElement(By.linkText("Top Deals")).click();
		Set<String> s1=testContextSetup.driver.getWindowHandles();
		Iterator<String> i1=s1.iterator();
		String parentWindow=i1.next();
		String childWindow=i1.next();
		
		testContextSetup.driver.switchTo().window(childWindow);
		testContextSetup.driver.findElement(By.xpath("//input[@type='search']")).sendKeys("hello");
		 Thread.sleep(2000);
		 offerPageProduct=testContextSetup.driver.findElement(By.className("text-center")).getText();
		
		System.out.println("Then Kumar :" + offerPageProduct);
	}
	
	@Then("validate Product name")
	public void validate_Product_name()
	{
		Assert.assertNotEquals(testContextSetup.landingpageProduct, offerPageProduct);
	}
	
	

}
