package stepDefinations;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import util.TestContextSetup;

public class LandingPageStepDefinition
{
  //public WebDriver driver;
  //public String landingpageProduct;
  //public String offerPageProduct;
  TestContextSetup testContextSetup;
  
    public LandingPageStepDefinition(TestContextSetup testContextSetup) {
    	
    	 
    	this.testContextSetup=testContextSetup;
    	
    	
    	
    	
		// TODO Auto-generated constructor stub
	}
 
	
	@Given("user is on GreenCart Landing page")
	public void user_is_on_green_cart_landing_page() {
		
		

   System.setProperty("webdriver.chrome.driver", "C:\\Users\\s.sivanna\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

	 //System.setProperty("webdriver.chrome.driver","C:/Users/s.sivanna/Downloads/chromedriver-win64/chromedriver-win64/chromedriver");
	  	    
	  testContextSetup.driver = new ChromeDriver();
	  testContextSetup.driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
	  //driver.findElement(By.xpath("//input[@type='search']")).sendKeys("hi");
	  String title=testContextSetup.driver.getTitle();
	  System.out.println("Broser title is : " + title);
	  testContextSetup.driver.manage().window().maximize();
		
		System.out.println("Given Kumar");
		
		//driver.quit();
	}
	@When("search search with Shortname Tom and extraced actual name of project")
	public void search_search_with_shortname_tom_and_extraced_actual_name_of_project() throws InterruptedException {
		testContextSetup.driver.findElement(By.xpath("//input[@type='search']")).sendKeys("hi");
    
     Thread.sleep(2000);
    
     testContextSetup.landingpageProduct=testContextSetup.driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div/div/h2")).getText();
     
     System.out.println(testContextSetup.landingpageProduct);
    
	}
	
	
	
	
	
}