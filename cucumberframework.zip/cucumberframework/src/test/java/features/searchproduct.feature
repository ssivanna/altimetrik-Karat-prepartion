Feature: Search and place the order for product 
Scenario: Search Expericne for product search in both home and offer page 

Given user is on GreenCart Landing page 
When search search with Shortname Tom and extraced actual name of project 
Then user search for same shortname in offers page to check if product exist 
And  validate Product name 



